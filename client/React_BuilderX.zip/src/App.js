import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import "./icons.js";
import Untitled from "./screens/Untitled";
import Discover from "./screens/Discover";
import Index from "./screens/Index";
import Song from "./screens/Song";
import Goodnight from "./screens/Goodnight";
import Info from "./screens/Info";

function App() {
  return (
    <Router>
      <Route path="/" exact component={Untitled} />
      <Route path="/Untitled/" exact component={Untitled} />
      <Route path="/Discover/" exact component={Discover} />
      <Route path="/Index/" exact component={Index} />
      <Route path="/Song/" exact component={Song} />
      <Route path="/Goodnight/" exact component={Goodnight} />
      <Route path="/Info/" exact component={Info} />
    </Router>
  );
}

export default App;
