import React, { Component } from "react";
import styled, { css } from "styled-components";

function Goodnight(props) {
  return (
    <Container>
      <Group2>
        <Group>
          <ElementsImgArtist>
            <svg
              viewBox="0 0 31.25 31.25"
              style={{
                height: 31,
                width: 31,
                backgroundColor: "transparent",
                borderColor: "transparent",
                marginLeft: 1
              }}
            >
              <path
                strokeWidth={0}
                fill="rgba(254,248,238,1)"
                d="M15.59 31.25 C7.41 31.25 0.70 24.98 0.00 16.98 C0.04 16.21 0.67 15.59 1.45 15.59 C1.90 15.59 2.30 15.79 2.57 16.11 C2.58 16.12 2.59 16.11 2.59 16.08 C4.32 17.92 6.77 19.07 9.50 19.07 C14.78 19.07 19.07 14.79 19.07 9.50 C19.07 6.75 17.90 4.30 16.05 2.57 C16.05 2.56 16.07 2.56 16.06 2.55 C15.77 2.28 15.59 1.90 15.59 1.47 C15.59 0.68 16.21 0.05 16.99 0.00 C24.98 0.71 31.25 7.41 31.25 15.59 C31.25 24.24 24.24 31.25 15.59 31.25 Z"
              ></path>
            </svg>
          </ElementsImgArtist>
          <Text>Good Night</Text>
        </Group>
        <EveryNightASong>
          Every night, a song, a passage, a good night, accompany you to sleep.
        </EveryNightASong>
      </Group2>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(29,27,37,1);
  flex-direction: column;
  height: 100vh;
  width: 100vw;
`;

const Group2 = styled.div`
  height: 156px;
  width: 297px;
  flex-direction: column;
  display: flex;
  margin-top: 150px;
  margin-left: 59px;
`;

const Group = styled.div`
  height: 65px;
  width: 92px;
  flex-direction: column;
  display: flex;
  margin-left: 94px;
`;

const ElementsImgArtist = styled.div`
  height: 32px;
  width: 33px;
  flex-direction: column;
  display: flex;
  margin-left: 29px;
`;

const Text = styled.span`
  font-family: Arial;
  color: rgba(254,248,238,1);
  text-align: center;
  font-size: 17px;
  margin-top: 9px;
  box-shadow: 0px 2px 5px  1px rgba(254,248,238,0.6788100090579711) ;
`;

const EveryNightASong = styled.span`
  font-family: Arial;
  height: 80px;
  width: 297px;
  color: rgba(254,248,238,1);
  text-align: center;
  font-size: 14px;
  letter-spacing: -0.1944444px;
  margin-top: 11px;
  box-shadow: 0px 2px 5px  1px rgba(254,248,238,0.6788100090579711) ;
`;

export default Goodnight;
